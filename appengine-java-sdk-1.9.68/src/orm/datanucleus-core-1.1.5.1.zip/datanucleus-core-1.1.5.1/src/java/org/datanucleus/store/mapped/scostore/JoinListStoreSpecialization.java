/**********************************************************************
 Copyright (c) 2007 Andy Jefferson and others. All rights reserved.
 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0

 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.

 Contributors:
 ...
 **********************************************************************/
package org.datanucleus.store.mapped.scostore;

import java.util.Collection;

import org.datanucleus.StateManager;

/**
 * Specialization interface for {@link JoinListStore}. {@link JoinListStore} delegates to instances of 
 * this interface for behavior that is tied to a specific datastore implementation.
 */
public interface JoinListStoreSpecialization extends AbstractListStoreSpecialization
{
    void removeAt(StateManager sm, int index, int size, ElementContainerStore ecs);

    boolean removeAll(int currentListSize, int[] indices, Collection elements, StateManager sm, 
            ElementContainerStore ecs);

    void set(Object element, int index, StateManager sm, ElementContainerStore ecs);

    boolean internalAdd(StateManager sm, ElementContainerStore ecs, int start, boolean atEnd, Collection c, 
            int currentListSize, int shift);
}
