package javax.persistence.criteria;

public enum TrimSpec {
    LEADING, TRAILING, BOTH 
}
