package javax.persistence.criteria;

public interface OrderByItem
{

}
