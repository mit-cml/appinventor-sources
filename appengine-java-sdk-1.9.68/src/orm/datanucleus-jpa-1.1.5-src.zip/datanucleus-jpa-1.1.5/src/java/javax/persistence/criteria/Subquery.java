package javax.persistence.criteria;

public interface Subquery extends PredicateOperand
{

}
