package javax.persistence;

public enum CachePutMode
{
    /** 
     * Insert/update entity data into cache when read from database and when 
     * committed into database: this is the default behavior.
     */
    USE,
    /** Don't insert into cache. */
    BYPASS,
    /** Force refresh of cache for items read from database. */
    REFRESH
}