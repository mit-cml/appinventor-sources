Core
====
This project is the prerequisite of any application using DataNucleus. 
Other DataNucleus projects depend on this project.

This project is licensed by the Apache 2 license which you should have received with this.
