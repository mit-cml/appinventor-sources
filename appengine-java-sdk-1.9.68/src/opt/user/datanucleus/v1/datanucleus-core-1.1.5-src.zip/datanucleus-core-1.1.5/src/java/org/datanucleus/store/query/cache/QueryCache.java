/**********************************************************************
Copyright (c) 2009 Andy Jefferson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

Contributors:
   ...
**********************************************************************/
package org.datanucleus.store.query.cache;

/**
 * Interface to be implemented by a query cache.
 */
public interface QueryCache
{
    /**
     * Method to close the cache when no longer needed. Provides a hook to release resources etc.
     */
    void close();

    /**
     * Evict the query from the query cache.
     * @param queryKey Key for the query to evict (single-string form).
     */
    void evict(String queryKey);

    /**
     * Method to clear the cache.
     */
    void clear();

    /**
     * Accessor for whether the cache is empty.
     * @return Whether it is empty.
     */
    boolean isEmpty();

    /**
     * Accessor for the total number of queries in the query cache.
     * @return Number of queries
     */
    int size();

    /**
     * Accessor for an object from the cache.
     * @param queryKey The query key
     * @return The cached query
     */
    CachedQuery get(String queryKey);

    /**
     * Method to put an object in the cache.
     * @param queryKey The query key
     * @param cachedQuery The cached query
     * @return The cached query previously associated with this query
     */
    CachedQuery put(String queryKey, CachedQuery cachedQuery);

    /**
     * Accessor for whether the specified query is in the cache
     * @param queryKey The query key
     * @return Whether it is in the cache
     */
    boolean contains(String queryKey);
}