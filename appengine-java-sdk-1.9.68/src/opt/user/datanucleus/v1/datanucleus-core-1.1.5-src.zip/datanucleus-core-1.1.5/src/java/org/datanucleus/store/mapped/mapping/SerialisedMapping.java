/**********************************************************************
Copyright (c) 2003 Erik Bengtson and others. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
 

Contributors:
2003 Andy Jefferson - coding standards
    ...
**********************************************************************/
package org.datanucleus.store.mapped.mapping;

import org.datanucleus.ClassLoaderResolver;
import org.datanucleus.ClassNameConstants;
import org.datanucleus.store.mapped.expression.LogicSetExpression;
import org.datanucleus.store.mapped.expression.ObjectExpression;
import org.datanucleus.store.mapped.expression.ObjectLiteral;
import org.datanucleus.store.mapped.expression.QueryExpression;
import org.datanucleus.store.mapped.expression.ScalarExpression;

/**
 * Maps a field as serialised.
 */
public class SerialisedMapping extends SingleFieldMapping
{
    /**
     * Accessor for a sample value for this type.
     * @return The sample value
     */
	public Object getSampleValue(ClassLoaderResolver clr)
    {
        return null;
    }

    /**
     * Accessor for the (Java) type of data represented here
     * @return java.lang.Object
     */
    public Class getJavaType()
    {
        return Object.class;
    }

    /**
     * Accessor for the name of the java-type actually used when mapping the particular datastore
     * field. Returns Serializable since the object needs to be Serialisable
     * @param index requested datastore field index.
     * @return the name of java-type for the requested datastore field.
     */
    public String getJavaTypeForDatastoreMapping(int index)
    {
        return ClassNameConstants.JAVA_IO_SERIALIZABLE;
    }

    // ------------------------------------- JDOQL Methods -------------------------------------------
    
    public ScalarExpression newLiteral(QueryExpression qs, Object value)
    {
        return new ObjectLiteral(qs, this, value,getType());
    }

    public ScalarExpression newScalarExpression(QueryExpression qs, LogicSetExpression te)
    {
        return new ObjectExpression(qs, this, te);
    }
}