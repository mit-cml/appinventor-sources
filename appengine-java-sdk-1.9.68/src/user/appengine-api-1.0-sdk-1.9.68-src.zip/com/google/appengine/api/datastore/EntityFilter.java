// Copyright 2010 Google Inc. All Rights Reserved.

package com.google.appengine.api.datastore;
