// Copyright 2012 Google Inc. All rights reserved.
package com.google.appengine.api.channel;

import com.google.appengine.spi.FactoryProvider;
import com.google.appengine.spi.ServiceProvider;
import com.google.auto.service.AutoService;

/**
 * Factory provider for {@link IChannelServiceFactory}.
 *
 * <p><b>Note:</b> This class is not intended for end users.
 *
 * @deprecated This API has been <a
 *     href="https://cloud.google.com/appengine/docs/deprecations/channel">deprecated</a>.
 */
@Deprecated
@AutoService(FactoryProvider.class)
@ServiceProvider(precedence = Integer.MIN_VALUE)
public final class IChannelServiceFactoryProvider extends FactoryProvider<IChannelServiceFactory> {

  private final ChannelServiceFactoryImpl implementation = new ChannelServiceFactoryImpl();

  public IChannelServiceFactoryProvider() {
    super(IChannelServiceFactory.class);
  }

  @Override
  protected IChannelServiceFactory getFactoryInstance() {
    return implementation;
  }

}
